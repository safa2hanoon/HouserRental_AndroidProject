package edu.berziet.houserental;

public class ApiError {
		private boolean valid,success;
		private ErrorResponse errorResponse;
		
		public ApiError(boolean valid, boolean success, ErrorResponse errorResponse) {
			super();
			this.valid = valid;
			this.success = success;
			this.errorResponse = errorResponse;
		}
		public ApiError() {
			super();
			// TODO Auto-generated constructor stub
		}
		public boolean isValid() {
			return valid;
		}
		public void setValid(boolean valid) {
			this.valid = valid;
		}
		public boolean isSuccess() {
			return success;
		}
		public void setSuccess(boolean success) {
			this.success = success;
		}
		public ErrorResponse getErrorResponse() {
			return errorResponse;
		}
		public void setErrorResponse(ErrorResponse errorResponse) {
			this.errorResponse = errorResponse;
		}
		
}
