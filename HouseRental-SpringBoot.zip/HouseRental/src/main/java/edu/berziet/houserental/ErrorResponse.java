package edu.berziet.houserental;

import java.util.List;

public class ErrorResponse {
    private List<ErrorModel> errorMessage;

	public ErrorResponse(List<ErrorModel> errorMessage) {
		super();
		this.errorMessage = errorMessage;
	}

	public ErrorResponse() {
		super();
	}

	public List<ErrorModel> getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(List<ErrorModel> errorMessage) {
		this.errorMessage = errorMessage;
	}
    
}
